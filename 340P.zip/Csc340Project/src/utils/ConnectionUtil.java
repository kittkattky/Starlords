package utils;

/**
 * This class connects to the server database
 *
 * @author Kahlie Last Updated: 2/17/2020
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;







public class ConnectionUtil {
    
    private static final String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";


    
    Connection con = null;
    public static Connection conDB() throws ClassNotFoundException{
        try {
            //Class.forName("com.mysql.jdbc.Driver");
            Class.forName(DRIVER);
           // Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/databases", "kahlie", "12345");
           // Connection con = DriverManager.getConnection("jdbc:derby:C:/Users/brian/Documents/NetBeansProjects/Csc340Project/test");
            Connection con = DriverManager.getConnection("jdbc:derby:databases;create=true");

            con.setSchema("APP");
            return con;
        } catch (SQLException ex) {
            System.err.println("ConnectionUtil : "+ex.getMessage());
           return null;
        }
        
    }
    
}